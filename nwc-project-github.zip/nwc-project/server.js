// NWC Project - zero-dependency server. Run: node server.js  (Node 16+)
// Env: PORT, ADMIN_PASS (admin NAIF password), GUEST_PASS (optional guest account)
const http=require('http'),https=require('https'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,D=path.join(__dirname,'data'),F=path.join(D,'db.json'),U=path.join(D,'uploads');
fs.mkdirSync(U,{recursive:true});
const hash=(p,s)=>crypto.scryptSync(p,s,32).toString('hex');
const mk=(name,pass,role,kind)=>{const salt=crypto.randomBytes(8).toString('hex');return{name,salt,h:hash(pass,salt),role,kind}};
const ADMIN_PASS=process.env.ADMIN_PASS||crypto.randomBytes(6).toString('hex');
let db,first=false;try{db=JSON.parse(fs.readFileSync(F))}catch(e){first=true;db={secret:crypto.randomBytes(24).toString('hex'),users:[mk('NAIF',ADMIN_PASS,'admin','admin')].concat(process.env.GUEST_PASS?[mk('guest',process.env.GUEST_PASS,'user','guest')]:[]),tasks:[],visits:[],log:[]}}
const save=()=>fs.writeFileSync(F,JSON.stringify(db));save();
const SEED=JSON.parse(fs.readFileSync(path.join(__dirname,'seed.json'),'utf8'));
if(!db.catalog){db.catalog=SEED.catalog;db.quotes=SEED.quotes;save()}
const TEAM=[['Aziz','user','technician'],['Shihab','user','technician'],['Hani','user','contractor'],['Abdulmajeed','manager','manager'],['Abdullah','manager','manager']],fresh=[];
TEAM.forEach(([n,r,k])=>{if(!db.users.some(u=>u.name.toLowerCase()===n.toLowerCase())){const pw=crypto.randomBytes(5).toString('hex');db.users.push(mk(n,pw,r,k));fresh.push(n+' / '+pw)}});
if(fresh.length){save();const msg='Initial passwords (users can change them from the app; admin can reset from Team tab):\n'+fresh.join('\n');console.log(msg);fs.writeFileSync(path.join(D,'initial-passwords.txt'),msg+'\n')}
const PRIV=t=>t==='admin'||t==='manager'||t==='viewer';
db.audit=db.audit||[];db.logins=db.logins||[];
db.settings=Object.assign({slaDays:5,stageDays:[1,.5,1,.5,1,.5,.25,.25],notifyUrl:'',tgToken:'',tgChat:'',waToken:'',waPhoneId:'',waTo:'',waTemplate:'',waLang:'ar'},db.settings||{});if(JSON.stringify(db.settings.stageDays)===JSON.stringify([1,.5,.5,.5,1,.5,.5,.5]))db.settings.stageDays=[1,.5,1,.5,1,.5,.25,.25];
db.settings.events=Object.assign({new:true,report:true,status:true,sla:true},db.settings.events||{});
db.users.forEach(u=>{if(u.kind==='manager'&&u.role==='viewer')u.role='manager'});save();
const dataFor=u=>{const t=tier(u),P=PRIV(t);
 return{me:pub(u),settings:{slaDays:db.settings.slaDays,stageDays:db.settings.stageDays},users:t==='contractor'?[]:db.users.filter(x=>P||['technician','contractor'].includes(x.kind)).map(pub),tasks:db.tasks.filter(k=>mine(u,k)).map(k=>clean(u,k)),visits:P?db.visits:t==='tech'?db.visits.filter(z=>z.by===u.name):[],log:P?db.log.slice(-40):t==='tech'?db.log.filter(z=>z.by===u.name).slice(-40):[],...(P?{catalog:db.catalog,quotes:db.quotes}:{})}};
if(first&&!process.env.ADMIN_PASS)console.log('First run - admin login: NAIF / '+ADMIN_PASS+'  (set ADMIN_PASS env var to choose your own)');
const sign=n=>n+'.'+crypto.createHmac('sha256',db.secret).update(n).digest('hex');
const who=r=>{const m=/sid=([^;]+)/.exec(r.headers.cookie||'');if(!m)return;const v=decodeURIComponent(m[1]),i=v.lastIndexOf('.');if(i<0||sign(v.slice(0,i))!==v)return;return db.users.find(u=>u.name===v.slice(0,i))};
const same=(a,b)=>String(a||'').toLowerCase()===String(b||'').toLowerCase();
const tier=u=>u.role==='admin'?'admin':u.role==='manager'?'manager':u.role==='viewer'?'viewer':u.kind==='contractor'?'contractor':'tech';
const mine=(u,k)=>{const t=tier(u);return PRIV(t)||(t==='contractor'?same(k.con,u.name):(same(k.tech,u.name)||k.by===u.name))};
const HID=['quote','po','inv','cert','appr','email'];
const clean=(u,k)=>{const t=tier(u);if(PRIV(t))return k;const{po,pay,inv,...r}=k,hid=t==='contractor'?HID.filter(z=>z!=='cert'):HID;return{...r,docs:(k.docs||[]).filter(d=>!hid.includes(d.label))}};
const pub=u=>({name:u.name,role:u.role,kind:u.kind});
const J=(res,c,o)=>{res.writeHead(c,{'Content-Type':'application/json'});res.end(JSON.stringify(o))};
const body=(r,lim=9e6)=>new Promise((ok,no)=>{let d='',n=0;r.on('data',c=>{n+=c.length;if(n>lim){no();r.destroy()}else d+=c});r.on('end',()=>{try{ok(JSON.parse(d||'{}'))}catch(e){ok({})}})});
const S=(x,n=300)=>String(x==null?'':x).slice(0,n);
const id=()=>Date.now().toString(36)+crypto.randomBytes(3).toString('hex');
db.catalog.forEach(c=>{if(!c.id)c.id=Date.now().toString(36)+crypto.randomBytes(3).toString('hex')});
const log=(by,act,ref)=>{db.log.push({t:Date.now(),by,act,ref:S(ref,80)});db.log=db.log.slice(-200)};
const STG=['مفتوحة - بانتظار زيارة الفني','تمت الزيارة - إعداد التسعير','معلّقة - بانتظار اعتماد السعر من المالك','السعر معتمد - جاهزة للمقاول','قيد التنفيذ - المقاول في الموقع','تم التنفيذ - تقرير قبل وبعد','شهادة الإنجاز - بانتظار اعتماد المالك','المالية - فاتورة وصرف','مغلقة'];
const WAIT=['الفني (زيارة وتقرير)','نايف (التسعير وإرساله)','عبدالله (اعتماد السعر)','المقاول (بدء التنفيذ)','المقاول (التنفيذ والتقرير)','المقاول (شهادة الإنجاز) ثم نايف','عبدالله (اعتماد الشهادة)','المالية (فاتورة وصرف)','—'];
const WA=process.env.WA_API_BASE||'https://graph.facebook.com/v26.0';
let dirty=false;setInterval(()=>{if(dirty){dirty=false;save()}},10000);
const ip=r=>String(r.headers['x-forwarded-for']||r.socket.remoteAddress||'').split(',')[0].trim();
const mv=(k,s,by)=>{k.hist=k.hist||[{st:0,at:k.at,by:k.by}];k.st=s;k.hist.push({st:s,at:Date.now(),by});if(s>=6&&!k.done)k.done=Date.now()};
const PAUSE_ST=2;
const pausedMs=k=>{const h=k.hist&&k.hist.length?k.hist:[{st:0,at:k.at}];let p=0;for(let i=0;i<h.length;i++){if(h[i].st===PAUSE_ST){const end=h[i+1]?h[i+1].at:Date.now();p+=Math.max(0,end-h[i].at)}}return p};
const slaOf=k=>{const end=k.st>=8?(((k.hist||[]).find(h=>h.st>=8)||{}).at||k.done||Date.now()):Date.now(),el=Math.max(0,(end-k.at)-pausedMs(k))/864e5,p=el/db.settings.slaDays;return{el,lvl:k.st>=8?'ok':p>=1?'late':p>=.6?'warn':'ok'}};
const notify=(text,ev)=>{const s=db.settings;if(s.events&&s.events[ev]===false)return;
 const post=(u,b,h)=>{try{const X=new URL(u),r=(X.protocol==='https:'?https:http).request(X,{method:'POST',headers:Object.assign({'Content-Type':'application/json'},h||{}),timeout:8000},z=>z.resume());r.on('error',()=>{});r.on('timeout',()=>r.destroy());r.end(JSON.stringify(b))}catch(e){}};
 if(s.tgToken&&s.tgChat)post('https://api.telegram.org/bot'+s.tgToken+'/sendMessage',{chat_id:s.tgChat,text});
 if(s.waToken&&s.waPhoneId&&s.waTo&&s.waTemplate){const txt=text.replace(/\s*\n+\s*/g,' | ').replace(/ {4,}/g,'   ').slice(0,900);
  s.waTo.split(',').map(z=>z.replace(/\D/g,'')).filter(Boolean).forEach(to=>post(WA+'/'+encodeURIComponent(s.waPhoneId)+'/messages',{messaging_product:'whatsapp',to,type:'template',template:{name:s.waTemplate,language:{code:s.waLang||'ar'},components:[{type:'body',parameters:[{type:'text',text:txt}]}]}},{Authorization:'Bearer '+s.waToken}))}
 if(s.notifyUrl)post(s.notifyUrl,{text,event:ev,at:Date.now(),source:'nwc-project'})};
setInterval(()=>{db.tasks.forEach(k=>{if(k.st>=8)return;const{el,lvl}=slaOf(k);if(lvl!=='ok'&&k.slaN!==lvl){k.slaN=lvl;notify((lvl==='late'?'🔴 تجاوزت المهلة: ':'🟠 قربت المهلة: ')+k.title+' - '+k.site+'\nمضى '+el.toFixed(1)+' من '+db.settings.slaDays+' أيام | بانتظار: '+WAIT[k.st],'sla');dirty=true}})},15*60*1000).unref();
const maskS=()=>{const s=db.settings,m=z=>z?'••••'+z.slice(-4):'';return{slaDays:s.slaDays,stageDays:s.stageDays,notifyUrl:m(s.notifyUrl),tgToken:m(s.tgToken),tgChat:s.tgChat,waToken:m(s.waToken),waPhoneId:s.waPhoneId,waTo:s.waTo,waTemplate:s.waTemplate,waLang:s.waLang,events:s.events}};
const MIME={'.jpg':'image/jpeg','.png':'image/png','.webp':'image/webp','.pdf':'application/pdf'};
http.createServer(async(req,res)=>{
 const p=new URL(req.url,'http://x').pathname,m=req.method;
 res.on('finish',()=>{const u=who(req);if(m==='GET'||p==='/api/login'||!u)return;db.audit.push({t:Date.now(),by:u.name,m,p,c:res.statusCode,ip:ip(req),n:res.note||''});if(db.audit.length>4000)db.audit=db.audit.slice(-4000);dirty=true});
 try{
  if(p==='/')return res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'}),res.end(fs.readFileSync(path.join(__dirname,'index.html')));
  if(p==='/api/login'&&m==='POST'){const b=await body(req),u=db.users.find(x=>x.name.toLowerCase()===S(b.u,40).toLowerCase());
   const ok=!!u&&hash(S(b.p,100),u.salt)===u.h;db.logins.push({t:Date.now(),name:S(b.u,40),ok,ip:ip(req),ua:S(req.headers['user-agent'],120)});if(db.logins.length>1000)db.logins.shift();dirty=true;
   if(!ok)return J(res,401,{e:1});
   res.setHeader('Set-Cookie','sid='+encodeURIComponent(sign(u.name))+'; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000');return J(res,200,pub(u))}
  const me=who(req);if(!me)return J(res,401,{e:1});
  if(p==='/api/logout'){res.setHeader('Set-Cookie','sid=; Path=/; Max-Age=0');return J(res,200,{})}
  if(p.startsWith('/uploads/')){const f=path.join(U,path.basename(p));if(!fs.existsSync(f))return J(res,404,{});res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'image/jpeg','Cache-Control':'private,max-age=86400'});return fs.createReadStream(f).pipe(res)}
  if(p==='/api/data')return J(res,200,dataFor(me));
  const T=tier(me);if(T==='viewer'&&m!=='GET'&&p!=='/api/password')return J(res,403,{});
  const admin=me.role==='admin',mgr=admin||me.role==='manager';let x;
  if(p==='/api/audit'&&m==='GET'){if(!admin)return J(res,403,{});return J(res,200,{audit:db.audit.slice(-400).reverse(),logins:db.logins.slice(-200).reverse()})}
  if(p==='/api/settings'){if(!admin)return J(res,403,{});if(m==='GET')return J(res,200,maskS());
   if(m==='POST'){const b=await body(req),s=db.settings,d=+b.slaDays;if(d>0&&d<=60)s.slaDays=d;if(Array.isArray(b.stageDays)&&b.stageDays.length===8)s.stageDays=b.stageDays.map(z=>Math.max(0,+z||0));
    for(const f of ['notifyUrl','tgToken','tgChat','waToken','waPhoneId','waTo','waTemplate','waLang'])if(typeof b[f]==='string'&&!b[f].startsWith('••'))s[f]=S(b[f],300).trim();
    if(b.events&&typeof b.events==='object')for(const e of ['new','report','status','sla'])if(e in b.events)s.events[e]=!!b.events[e];
    res.note='settings updated';save();return J(res,200,maskS())}}
  if(p==='/api/settings/test'&&m==='POST'){if(!admin)return J(res,403,{});notify('✅ NWC Project: test notification','test');return J(res,200,{})}
  if(x=/^\/api\/users\/([\w-]+)\/kind$/.exec(p)){if(!admin)return J(res,403,{});const b=await body(req),u=db.users.find(z=>z.name===x[1]),kd=S(b.kind,20);
   if(!u||u.name===me.name||!['technician','contractor','guest','manager','viewer'].includes(kd))return J(res,400,{});u.kind=kd;u.role=kd==='manager'?'manager':kd==='viewer'?'viewer':'user';res.note=u.name+' -> '+kd;save();return J(res,200,{})}
  if(p==='/api/password'&&m==='POST'){const b=await body(req);if(hash(S(b.old,100),me.salt)!==me.h||S(b.pw,100).length<6)return J(res,400,{});me.salt=crypto.randomBytes(8).toString('hex');me.h=hash(S(b.pw,100),me.salt);save();return J(res,200,{})}
  if(x=/^\/api\/users\/([\w-]+)\/password$/.exec(p)){if(!admin)return J(res,403,{});const b=await body(req),u=db.users.find(z=>z.name===x[1]);if(!u||S(b.pass,100).length<6)return J(res,400,{});u.salt=crypto.randomBytes(8).toString('hex');u.h=hash(S(b.pass,100),u.salt);save();return J(res,200,{})}
  if(p==='/api/catalog'&&m==='POST'){if(!admin)return J(res,403,{});const b=await body(req),pr=+b.price;if(!S(b.code).trim()||!S(b.en).trim()||!(pr>=0))return J(res,400,{});
   const c=b.id&&db.catalog.find(z=>z.id===b.id),rec={code:S(b.code,20).trim(),en:S(b.en,200).trim(),ar:S(b.ar,200).trim(),unit:'EACH',price:pr,group:S(b.group,40).trim()||'GENERAL'};
   if(c){res.note=c.code+': '+c.price+' -> '+pr;Object.assign(c,rec)}else{db.catalog.push({id:id(),...rec});res.note='new item '+rec.code}
   save();return J(res,200,{})}
  if(x=/^\/api\/catalog\/(\w+)$/.exec(p)){if(m==='DELETE'&&admin){const c=db.catalog.find(z=>z.id===x[1]);res.note=c?'deleted '+c.code:'';db.catalog=db.catalog.filter(z=>z.id!==x[1]);save();return J(res,200,{})}return J(res,403,{})}
  if(p==='/api/quotes'&&m==='POST'){if(!mgr)return J(res,403,{});const b=await body(req);
   const ls=(Array.isArray(b.lines)?b.lines:[]).slice(0,60).map(l=>{const c=db.catalog.find(z=>z.code===l.code&&z.en===l.en),q=+l.qty;return c&&q>0&&q<=1e5?{code:c.code,en:c.en,ar:c.ar,qty:q,price:c.price}:null});
   if(!S(b.location).trim()||!ls.length||ls.includes(null))return J(res,400,{});
   const d=/^\d{4}-\d{2}-\d{2}$/.test(b.date)?b.date:new Date().toISOString().slice(0,10),yr=d.slice(0,4),n=Math.max(0,...db.quotes.filter(q=>q.id.startsWith('Q-'+yr+'-')).map(q=>+q.id.split('-')[2]))+1;
   const q={id:'Q-'+yr+'-'+String(n).padStart(3,'0'),date:d,location:S(b.location,200),group:S(b.group,40)||'CCTV SYSTEM',delivery:S(b.delivery,20)||'2 Weeks',po:S(b.po,40),ticket:S(b.ticket,30),validDays:15,guarantee:'1 Year',payment:'100% Advance Delivery',vatRate:15,signedBy:'Abdulrahman Saad - Operation & Maintenance Manager',client:'NWC - \u0634\u0631\u0643\u0629 \u0627\u0644\u0645\u064a\u0627\u0647 \u0627\u0644\u0648\u0637\u0646\u064a\u0629',lines:ls,by:me.name,createdAt:Date.now()};
   db.quotes.push(q);log(me.name,'quote',q.id);save();return J(res,200,q)}
  if(x=/^\/api\/quotes\/([\w-]+)$/.exec(p)){if(m==='DELETE'&&admin){db.quotes=db.quotes.filter(q=>q.id!==x[1]);save();return J(res,200,{})}return J(res,403,{})}
  if(p==='/api/tasks'&&m==='POST'){const b=await body(req);if(!S(b.title)||!S(b.site))return J(res,400,{});
   const k={id:id(),title:S(b.title),site:S(b.site),asset:S(b.asset,60),desc:S(b.desc,1000),pr:['lo','me','hi'].includes(b.pr)?b.pr:'me',due:/^\d{4}-\d{2}-\d{2}$/.test(b.due)?b.due:new Date(Date.now()+db.settings.slaDays*864e5).toISOString().slice(0,10),done:null,con:T==='contractor'?me.name:S(b.con,60),tech:S(b.tech,60),cat:['cctv','arm','pull','cards','labor'].includes(b.cat)?b.cat:'',st:0,by:me.name,at:Date.now(),photos:[],reports:[],docs:[],hist:[{st:0,at:Date.now(),by:me.name}]};
   db.tasks.unshift(k);log(me.name,'new',k.title);notify('🆕 تذكرة جديدة: '+k.title+' - '+k.site+' ('+me.name+')\n⏱ المهلة: '+db.settings.slaDays+' أيام','new');save();return J(res,200,k)}
  if(x=/^\/api\/tasks\/(\w+)(\/status|\/photo|\/due|\/report|\/doc|\/fin|\/edit)?$/.exec(p)){const k=db.tasks.find(a=>a.id===x[1]);if(!k)return J(res,404,{});if(!mine(me,k))return J(res,403,{});
   if(m==='DELETE'&&!x[2]){if(!admin)return J(res,403,{});[...k.photos,...(k.reports||[]).flatMap(r=>r.photos),...(k.docs||[])].forEach(f=>fs.rmSync(path.join(U,f.file),{force:true}));db.tasks=db.tasks.filter(a=>a!==k);save();return J(res,200,{})}
   if(m==='POST'&&x[2]==='/status'){const b=await body(req),s=+b.st;if(!(s>=0&&s<=8))return J(res,400,{});if(!mgr&&!(T==='contractor'&&s===4&&k.st===3))return J(res,403,{});
    if(s>=5&&!(k.reports&&k.reports.length)&&!(k.photos.some(p=>p.type==='before')&&k.photos.some(p=>p.type==='after')))return J(res,400,{e:'photos'});mv(k,s,me.name);res.note='-> '+s;log(me.name,'status'+s,k.title);notify('🔄 '+k.title+'\nالمرحلة: '+STG[s]+'\nبانتظار: '+WAIT[s]+' | '+me.name,'status');save();return J(res,200,{})}
   if(m==='POST'&&x[2]==='/due'){if(!mgr)return J(res,403,{});const b=await body(req);k.due=/^\d{4}-\d{2}-\d{2}$/.test(b.due)?b.due:'';save();return J(res,200,{})}
   if(m==='POST'&&x[2]==='/fin'){if(!mgr)return J(res,403,{});const b=await body(req);k.po=S(b.po,40);k.pay=['none','pending','issued','approved','paid'].includes(b.pay)?b.pay:'none';k.inv=S(b.inv,40);log(me.name,'fin',k.title);save();return J(res,200,{})}
   if(m==='POST'&&x[2]==='/edit'){if(!mgr)return J(res,403,{});const b=await body(req),ch=[];
    for(const[f,n]of[['title',200],['site',200],['asset',60],['desc',1000],['tech',60],['con',60]])if(b[f]!==undefined&&S(b[f],n)!==k[f]){ch.push(f+': '+S(k[f],40)+' -> '+S(b[f],40));k[f]=S(b[f],n)}
    if(['lo','me','hi'].includes(b.pr)&&b.pr!==k.pr){ch.push('pr: '+k.pr+' -> '+b.pr);k.pr=b.pr}
    if(['cctv','arm','pull','cards','labor'].includes(b.cat)&&b.cat!==k.cat){ch.push('cat: '+k.cat+' -> '+b.cat);k.cat=b.cat}
    res.note=ch.join(' | ').slice(0,400);save();return J(res,200,{})}
   if(m==='POST'&&x[2]==='/report'){const b=await body(req,25e6),imgs=a=>(Array.isArray(a)?a:[]).slice(0,12).map(q=>/^data:image\/(jpeg|png|webp);base64,(.+)$/.exec(S(q,4e6))).filter(Boolean);
    const bf=imgs(b.before),af=imgs(b.after);if(!S(b.notes).trim()||!bf.length||!af.length)return J(res,400,{e:'need'});
    const put=(g,type)=>{const file=id()+'.'+(g[1]==='jpeg'?'jpg':g[1]);fs.writeFileSync(path.join(U,file),Buffer.from(g[2],'base64'));return{file,type}};
    (k.reports=k.reports||[]).push({id:id(),by:me.name,at:Date.now(),cat:S(b.cat,20),kind:S(b.kind,20),notes:S(b.notes,3000),done:S(b.done,1500),parts:S(b.parts,500),photos:[...bf.map(g=>put(g,'before')),...af.map(g=>put(g,'after'))]});
    db.visits.unshift({id:id(),site:k.site,note:'['+S(b.kind,20)+'] '+k.title,by:me.name,at:Date.now()});if(k.st<1)mv(k,1,me.name);log(me.name,'report',k.title);notify('📝 تقرير زيارة: '+k.title+' - '+k.site+' ('+me.name+')','report');save();return J(res,200,{})}
   if(m==='POST'&&x[2]==='/doc'){const b=await body(req,14e6),g=/^data:(application\/pdf|image\/jpeg|image\/png|image\/webp);base64,(.+)$/.exec(S(b.data,13e6));if(!g||!S(b.label))return J(res,400,{});if(!mgr&&!['report','other',...(T==='contractor'?['cert']:[])].includes(b.label))return J(res,403,{});
    const file=id()+'.'+({'application/pdf':'pdf','image/jpeg':'jpg','image/png':'png','image/webp':'webp'})[g[1]];fs.writeFileSync(path.join(U,file),Buffer.from(g[2],'base64'));
    (k.docs=k.docs||[]).push({id:id(),file,name:S(b.name,80),label:S(b.label,30),by:me.name,at:Date.now()});log(me.name,'doc',k.title);save();return J(res,200,{})}
   if(m==='POST'&&x[2]==='/photo'){const b=await body(req),g=/^data:image\/(jpeg|png|webp);base64,(.+)$/.exec(S(b.img,9e6));if(!g)return J(res,400,{});
    const file=id()+'.'+(g[1]==='jpeg'?'jpg':g[1]);fs.writeFileSync(path.join(U,file),Buffer.from(g[2],'base64'));
    k.photos.push({file,type:b.type==='after'?'after':'before',by:me.name,at:Date.now()});log(me.name,'photo',k.title);save();return J(res,200,{})}}
  if(p==='/api/visits'&&m==='POST'){if(T==='contractor')return J(res,403,{});const b=await body(req);if(!S(b.site))return J(res,400,{});db.visits.unshift({id:id(),site:S(b.site),note:S(b.note,500),by:me.name,at:Date.now()});log(me.name,'visit',b.site);save();return J(res,200,{})}
  if(x=/^\/api\/visits\/(\w+)$/.exec(p)){if(m==='DELETE'&&admin){db.visits=db.visits.filter(a=>a.id!==x[1]);save();return J(res,200,{})}return J(res,403,{})}
  if(p==='/api/users'&&m==='POST'){if(!admin)return J(res,403,{});const b=await body(req);
   if(!/^[\w-]{2,24}$/.test(S(b.name,30))||S(b.pass,100).length<4||db.users.some(u=>u.name.toLowerCase()===b.name.toLowerCase()))return J(res,400,{});
   const kd=['technician','contractor','guest','manager','viewer'].includes(b.kind)?b.kind:'technician';db.users.push(mk(b.name,b.pass,kd==='manager'?'manager':kd==='viewer'?'viewer':'user',kd));save();return J(res,200,{})}
  if(x=/^\/api\/users\/([\w-]+)$/.exec(p)){if(m==='DELETE'&&admin&&x[1]!==me.name){db.users=db.users.filter(u=>u.name!==x[1]);save();return J(res,200,{})}return J(res,403,{})}
  J(res,404,{});
 }catch(e){try{J(res,500,{})}catch(_){}}
}).listen(PORT,()=>console.log('NWC Project running on http://localhost:'+PORT));
