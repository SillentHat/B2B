# NWC Project

Maintenance & operations tracker for the National Water Company security systems contract
(cameras, gates, access control). Bilingual (Arabic / English).

> **Status: temporary / pilot.** The live demo below uses fake data stored in the visitor's own browser.

## Features
- Role-based login (admin, technician, contractor, guest) - every ticket, photo and site visit is stamped automatically with the signed-in user
- 9-stage workflow that mirrors the contract process: owner email > technicians dispatched & report > quotation per PO > owner approval > contractor on site > before/after report approved > completion certificate > approval certificate & invoice > closed
- Site-visit reports: system (CCTV, arm barriers, pull gates, access cards, labor), work type (maintenance, installation, cards, inspection), findings, work done, parts. **A report is rejected unless it has written findings plus before AND after photos**, and a ticket cannot reach the report-approved stage without one
- Document attachments per ticket (owner email, PO, quotation, completion / approval certificates, invoice) - PDF or image
- Admin-only quotation register and price list (11 quotations / 14 BOQ items pre-loaded from `seed.json`)
- **Quotation generator**: pick BOQ items from the price list, VAT and total computed, amount in words, print-ready PDF in a modern template; numbering Q-YYYY-###; link to a ticket / PO
- Finance tracking per ticket (PO, invoice no., payment status) and an "awaiting payment" list with ageing
- One-click **weekly project report** (PDF) and **contractor performance** scorecard (on-time rate, average days, overdue)
- Due dates, overdue alerts, calendar view, site-visit log
- Live dashboard: KPIs, status breakdown, 14-day trend, upcoming deadlines, activity feed
- Arabic (RTL) and English (LTR) with one-click switch
- Zero dependencies - Node.js only

## Roles & permissions (enforced on the server)
| Role | Sees | Can do |
|---|---|---|
| **Owner** (NAIF) | everything | everything: users & passwords, roles, settings (SLA, notifications), audit + login logs, price-list editing, deleting |
| **Manager** (Abdullah, Abdulmajeed) | everything, incl. prices, finance, quotations | operational full access: open / edit tickets, change stages, quotations, finance fields, reports. Not: users, logs, settings, price-list editing, deleting |
| **Technician** | only tickets assigned to them / raised by them; own visits | visit reports (before/after photos), report documents, log visits, raise tickets. No prices, PO/invoice data, analytics or financial documents |
| **Contractor** | dashboard + own tickets | reports, "work started", completion certificate. No prices, finance, visits, team or other contractors |

On first start the server creates Aziz, Shihab (technicians), Hani (contractor), Abdulmajeed, Abdullah (managers) with random passwords written to `data/initial-passwords.txt` (also printed once). Owner can reset passwords / change roles from the **Team** tab; everyone can change their own password (key button).

## 5-day SLA workflow
Every ticket gets a deadline = creation + 5 days (editable in **Settings**) and per-stage time budgets. Each ticket shows elapsed/limit, who it is waiting on (technician visit & report > Naif pricing > Abdullah price approval > contractor start > contractor execution > contractor completion certificate then Naif > Abdullah certificate approval > finance) and turns orange/red as the limit approaches / passes.
**The clock pauses** while a ticket sits at "On hold - awaiting owner price approval" (stage 3): that waiting time is outside the team's control and is not counted against the 5 days. Stage history (who moved it and when) is stored per ticket.
Tickets list is filtered into three groups: **Open** (not yet visited), **In progress** (pricing through invoicing), **Closed**.

## Notifications
Settings > Notifications: Telegram bot (works in groups) and/or a generic Webhook (n8n, Make, Zapier or a WhatsApp gateway) - events: new ticket, visit report, stage change, SLA warning / breach. Each ticket also has a **WhatsApp** button that opens WhatsApp with a ready message (pick any contact or group).
Official WhatsApp automation needs the WhatsApp Business Platform (Cloud API) and, for groups, an Official Business Account (max 8 members per group).

## Audit
Owner-only **Logs** tab: every login (success / failure, IP, device) and every write action with who / what / result, including denied attempts and price changes.

## Live demo (static, fake data)
Enable GitHub Pages: **Settings > Pages > Deploy from a branch > `main` / `/docs`**.
Demo logins: `NAIF` / `demo`, `guest` / `guest`.

## Run the real system
```bash
node server.js            # Node 16+
```
First run prints the admin password (`NAIF / ...`). To choose your own:
```bash
ADMIN_PASS='your-strong-password' node server.js
# optional guest account
GUEST_PASS='something' ADMIN_PASS='...' node server.js
```
Data and photos are stored in `./data` (git-ignored). Back this folder up.
Add technicians and contractors from the **Team** tab (admin only).

## Deploy notes
- Put it behind HTTPS (Nginx + Let's Encrypt, or Cloudflare) - passwords are sent on login.
- Free hosts with ephemeral disks (e.g. Render free plan) **lose data** on restart. Use a VPS or a paid persistent disk for real data.
- Do not commit the `data/` folder or real passwords.

## Structure
```
server.js      API + auth + uploads (no dependencies)
index.html     Single-page dashboard
docs/          Static demo for GitHub Pages
```

---
## بالعربي
نظام متابعة صيانة المنظومة الأمنية لمشروع شركة المياه الوطنية: تذاكر، صور قبل وبعد، زيارات، تقويم، ولوحة تحكم حية بلغتين.
النسخة في `docs/` عرض تجريبي ببيانات وهمية. للنسخة الفعلية شغّل `node server.js` على سيرفر، واحفظ نسخة احتياطية من مجلد `data`.
